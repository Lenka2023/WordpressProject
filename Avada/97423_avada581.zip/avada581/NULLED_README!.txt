

Upload & Activate WordPress Web Template -> ( ...\Avada Theme\Avada_v5.8.1\Avada\ )
Upload & Activate WordPress Plugin "Fusion Builder" Nulled Version Manually -> ( ...\Avada Plugins\fusion-builder_v1.8.1_nulled.zip )
