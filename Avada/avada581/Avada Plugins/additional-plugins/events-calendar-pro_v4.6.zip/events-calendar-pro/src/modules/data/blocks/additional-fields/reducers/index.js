/**
 * Internal dependencies
 */
import fields from './fields';

export default fields;
