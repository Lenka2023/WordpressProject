/**
 * Internal dependencies
 */
import { PREFIX_COMMON_STORE } from '@moderntribe/common/data/utils';

export const WP_REQUEST = `${ PREFIX_COMMON_STORE }/WP_REQUEST`;
