<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__File_Reader' );


	class TribeEventsImporter_FileReader extends Tribe__Events__Importer__File_Reader {

	}