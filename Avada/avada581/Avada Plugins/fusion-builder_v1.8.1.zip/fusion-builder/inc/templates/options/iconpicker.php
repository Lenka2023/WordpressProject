<div class="fusion-iconpicker">
	<input type="text" class="fusion-icon-search" placeholder="Search Icons" />
	<div class='icon_select_container'></div>
	<input type="hidden" class="fusion-iconpicker-input" value="{{ option_value }}" id="{{ param.param_name }}" name="{{ param.param_name }}"/>
</div>
