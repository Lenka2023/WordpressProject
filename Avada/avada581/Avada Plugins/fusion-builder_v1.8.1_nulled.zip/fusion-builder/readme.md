# THEME FUSION PAGE BUILDER

Create awesome pages.



## INSTALLATION

* Download
* Install
* Enjoy

## FILTERS
fusion_builder_allowed_post_types - Post types that allow Fusion Builder to be used ( array )
fusion_builder_all_elements - Fusion Builder Elements ( array )
fusion_builder_ignored_elements - Fusion Builder Elements that are disabled ( array )
fusion_builder_column_layouts - Fusion Builder column element layotus ( array )
fusion_builder_inner_column_layouts - Fusion Builder nested column element layotus ( array )
fusion_builder_generators_column_layouts - Fusion Builder shortcode generator columns ( array )
fusion_builder_get_demo_pages - Fusion Builder demo pages ( array )
fusion_builder_import_message - Fusion Builder demo import message ( string )

## CREDITS

Theme Fusion
